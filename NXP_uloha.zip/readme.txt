Patrik Pricl 

Multiplex prescale

Algoritmus hlad� v�etky najlep�ie kombin�cie k dosiahnutiu dan�ho vstupu.

Uk�kov� model aj s uk�kov�mi vstupn�mi argumentmi je predpripraven�.


Vstup: Zadany pomocou ��sla a pr�pony MEGA alebo KILO s jednotkou na konci, alebo len ako ��slo. Inak chyba.

Priklad:

16MHz ; 16000kHz ; 16000000Hz ; 16000000



Ako prv� argument sa zad�va BUS_CLOCK a druh� po�adovan� v�stup.

Spustenie v priecinku prescale:
 
NXP.exe <arg1> <arg2> 

alebo

NXP.exe 


