#include <iostream>
#include <stdarg.h>
#include <cstring>
#include <vector>



class MX {
public:
    //retazec delitelov
    int* div;
    //vystup po deleni
    double val_out;
    //riadiaci vstup
    int cntr_in = 1;

    MX(){}

    //konstruktor pre vytvorenie pozadovaneho typu mx
    //params: type - predstavuje typ mx ktory je potrebne vytvorit
    MX(int type)
    {
        if(type == 1)
        {
            this->div =new int[5] {1,2,3,4,5};
        }
        else if( type == 2)
        {
            this->div =new int[5] {1,2,4,8,16};
        }
    }



    //predelenie vstupnej hodnoty
    void output(double val_in)
    {
        this->val_out = val_in / div[cntr_in-1];
    }

    //zvysovanie riadiaceho vstupu, pri najvyssom ide od znova
    int cntr_incr()
    {
        if (this->cntr_in == 5)
        {
            this->cntr_in = 1;
            return 1;
        }
        else
        {
            this->cntr_in += 1;
            return 0;
        }
    }
};



class Model {
public:

    // multiplexori
    MX *Multi_mx;
    //pocet mx
    int size_of_model;
    //vstupna hodnota BUS_CLOCK
    int input_val;
    //pozadovana hodnota
    int want_out_val;
    //vysledky
    std::vector<double> best_val_out;
    std::vector<int*> best_cntr_in;

    //konstrukcia modelu
    //pozostava z dvoch druhov mx
    //params: num_of_mx - pocet mx radenich za sebou
    //        ... - predstavuje vymenovane typy mx za sebou v modeli
    Model(int input, int want_out, int num_of_mx, ...){

        va_list valist;
        int i;
        int type;
        va_start(valist, num_of_mx);
        //ulozenie premennych modelu
        this->input_val = input;
        this->want_out_val = want_out;
        this->size_of_model = num_of_mx;
        this->Multi_mx =  new MX[num_of_mx];
        //ukladanie typov MX
        for(i = 0; i < num_of_mx;i++)
        {
            type = va_arg(valist, int);
            // predstavuje MX12345
            if ( type == 1)
            {
                MX mx = MX(1);
                Multi_mx[i] = mx;


            }
            //predstavuje MX124816
            else if (type == 2)
            {
                MX mx = MX(2);
                Multi_mx[i] = mx;
            }
        }

        va_end(valist);
    }

    //destructor
    ~Model()
    {
        for (int i = 0; i<this->best_cntr_in.size();i++)
        {
            delete[] this->best_cntr_in[i];
        }

        for (int i = 0; i<this->size_of_model;i++)
        {
            delete[] this->Multi_mx[i].div;
        }

        delete[] this->Multi_mx;

    }

    //zmena kombinacie riadiacich vstupov pre MX
    int change_cntr_in()
    {
        //postupoje sa od posledneho
        for(int i = this->size_of_model-1; i > -1; i--)
        {
            //ak sa preslo k prvemu mx a je na poslednej kombinacii riadiaceho vstupu
            //tak sa nastavi pretecenie co je cislo 6
            if( i==0 && this->Multi_mx[0].cntr_in == 5)
            {
                this->Multi_mx[0].cntr_in += 1;
                return 0;
            }
            //vracia sa index MX u ktoreho neprislo k zmene z 5 riadiaceho vstupu na 1
            if(!this->Multi_mx[i].cntr_incr())
            {
                return i;
            }
        }
        return 0;

    }

    void compare_save_best_prescale(double new_best_val)
    {
        //retazce vysledkou su prazdne
        if(this->best_val_out.empty())
        {
            int* arr = new int[this->size_of_model];
            for(int i = 0; i<this->size_of_model;i++)
            {
                arr[i] = this->Multi_mx[i].cntr_in;
            }
            this->best_val_out.push_back(new_best_val);
            this->best_cntr_in.push_back(arr);
            //delete arr;
        }
        //dosiahol sa lepsi vysledok
        else if(abs(this->best_val_out[0]-this->want_out_val) > abs(new_best_val-this->want_out_val))
        {
            this->best_cntr_in.clear();
            this->best_val_out.clear();
            int* arr = new int[this->size_of_model];
            for(int i = 0; i<this->size_of_model;i++)
            {
                arr[i] = this->Multi_mx[i].cntr_in;
            }
            this->best_val_out.push_back(new_best_val);
            this->best_cntr_in.push_back(arr);


        }
        // novy vysledok je rovnaky ako aktualny -> dalsia kombinacia
        else if(abs(this->best_val_out[0]-this->want_out_val) == abs(new_best_val-this->want_out_val))
        {
            int* arr = new int[this->size_of_model];
            for(int i = 0; i<this->size_of_model;i++)
            {
                arr[i] = this->Multi_mx[i].cntr_in;
            }
            this->best_val_out.push_back(new_best_val);
            this->best_cntr_in.push_back(arr);


        }
    }

    //prechod cez vsetky kombinacie riadiacich vstupum multiplexorov
    void find_best_prescale()
    {
        int i = 0;
        // aktualna hodnota je vstupna
        double act_val = this->input_val;
        //ak na pociatocnom mx doslo k preteceniu na riadiacom vstupe tak sa vykonali vsetky kombinacie
        while (this->Multi_mx[0].cntr_in < 6)
        {
            //prechod cez vsetky mx
            for(; i< this->size_of_model; i++)
            {
                //vypocet vystupu pre dany mx a ulozenie ako aktualnej hodnoty
                Multi_mx[i].output(act_val);
                act_val = Multi_mx[i].val_out;

            }
            //spracovanie vysledkou ci sa jedna o lepsie vysledky
            compare_save_best_prescale(act_val);
            //zacina sa od mx u ktoreho nedoslo k preteceniu
            i = change_cntr_in();
            //pre pociatocny mx treba ako aktualnu hodnotu nastavit vstupnu BUS CLOCK
            if(i == 0)
            {
                act_val = this->input_val;
            }
            //inak je aktualna hodnota vystupna z predchadzajuceho mx
            else
            {
                act_val = Multi_mx[i - 1].val_out;
            }
        }
    }

    //tisk vsetkych kombinacii k dosiahnutiu vysledku
    void print()
    {

        std::cout<<"--------------------------------------------"<<std::endl;
        std::cout<<std::endl<<"Pozadovana hodnota: "<<this->want_out_val<<"Hz"<<std::endl<<std::endl;
        std::cout<<"--------------------------------------------"<<std::endl;
        for(int i = 0; i<this->best_val_out.size();i++)
        {
            for(int j = 0; j<this->size_of_model;j++)
            {
                std::cout<<"Multiplexer "<<j+1<<" active input "<<this->best_cntr_in[i][j]<<std::endl;
            }

            std::cout<<"Achieved frequency ";

            char* str;
            if(int(this->best_val_out[i]) == this->best_val_out[i])
            {
                if(int(this->best_val_out[i]) %1000000 == 0)
                {
                    std::cout<<int(this->best_val_out[i]) /1000000<<"MHz"<<std::endl;
                }
                else if(int(this->best_val_out[i]) %1000 == 0)
                {
                    std::cout<<int(this->best_val_out[i]) /1000<<"kHz"<<std::endl;
                }
                else
                {
                    std::cout<<int(this->best_val_out[i]) <<"Hz"<<std::endl;
                }
            }
            else {
                std::cout << this->best_val_out[i] << "Hz" << std::endl;
            }

            std::cout<<"--------------------------------------------"<<std::endl;
        }

        std::cout<<""<<std::endl;
        std::cout<<"KONIEC VYPISU"<<std::endl;
    }


};


//spraovanie vstupnych argumentov
//params: argc - pocet vstupnych argumentov
//        argv - retazec argumentov
//        input_val - ukazovatel na premennu hodnoty vstupu (BUS_CLOCk)
//        want_out_val - ukazovatel na premennu pozadovanej vystupnej hodnoty
void arg_processing(int argc,char* argv[],int *input_val,int *want_out_val)
{
    // bez vstupnych argumentov - ulozenie predpripravenych hodnot
    if (argc == 1)
    {
        *input_val = 16000000;
        *want_out_val = 1000000;
    }
    // so vstupnymi parametrami
    else if (argc == 3)
    {

        char *prefix;

        // Spracovanie vstupnej hodnoty (BUS_CLOCK)

        *input_val = std::strtol(argv[1],&prefix,10);

        //S preponou M
        if(!strcmp(prefix, "MHz"))
        {
            *input_val *= 1000000;
        }
        //S preponou k
        else if(!strcmp(prefix, "kHz"))
        {
            *input_val *= 1000;
        }
        //bez prepony
        else if (strcmp(prefix,"") && strcmp(prefix, "Hz") )
        {

            std::cerr << "Bad argument" << std::endl ;
            exit(1);
        }

        //Spracovanie pozadovanej vystupnej hodnoty

        *want_out_val = std::strtol(argv[2],&prefix,10);
        if(!strcmp(prefix, "MHz"))
        {
            *want_out_val *= 1000000;
        }
        else if(!strcmp(prefix, "kHz"))

        {
            *want_out_val *= 1000;
        }
        else if (strcmp(prefix, "") && strcmp(prefix, "Hz") )
        {
            std::cerr << "Bad argument" << std::endl;
            exit(1);
        }


    }
}


int main(int argc, char* argv[]) {

    int input_val;
    int want_out_val;

    arg_processing(argc,argv,&input_val,&want_out_val);

    Model model(input_val,want_out_val,2,2,1);
    model.find_best_prescale();

    model.print();



    return 0;
}
